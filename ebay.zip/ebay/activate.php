<?php include("header_login.php") ?>


	<div class="jumbotron">
	<h1 class="text-center"> <?php activate_user();     ?></h1>
	</div>
	


</body>

</html>